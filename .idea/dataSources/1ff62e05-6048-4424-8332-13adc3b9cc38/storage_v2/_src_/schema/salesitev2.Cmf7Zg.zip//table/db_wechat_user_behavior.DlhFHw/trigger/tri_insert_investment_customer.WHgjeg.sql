create definer = root@localhost trigger tri_insert_investment_customer
  after INSERT
  on db_wechat_user_behavior
  for each row
BEGIN
 if (NEW.terminal_id = 28 and NEW.terminal_id is not null )
       then
	INSERT INTO investment_customer_behavior_read (openid)
VALUES
	(new.openid) ;
	end if;
	END;

